# Public Transport Delay Prediction — Results

> ⚠️ **No learnable signal found.** The best model is within 3% of the mean-only baseline (MAE 8.15 vs 8.15 min, R² ≈ -0.01). Together with the non-significant tests below, this means weather, events and timing are statistically unrelated to delay in this data. That's expected for a randomly generated dataset, and it's a valid result, not a bug.

Data: `public_transport_delays.csv` — 2000 trips after cleaning. Target: `actual_arrival_delay_min` (minutes).

## 1. Delay overview

|       |   delay_min |
|:------|------------:|
| count |     2000    |
| mean  |       13.32 |
| std   |        9.29 |
| min   |       -3    |
| 25%   |        5    |
| 50%   |       13    |
| 75%   |       21    |
| max   |       29    |

![](figures/01_target_distribution.png)

## 2. Weather effects

| weather_condition   |   trips |   mean_delay |   median_delay |   pct_delayed |
|:--------------------|--------:|-------------:|---------------:|--------------:|
| Rain                |     321 |        13.62 |             14 |         75.7  |
| Snow                |     343 |        13.53 |             14 |         75.22 |
| Clear               |     343 |        13.5  |             13 |         75.51 |
| Storm               |     337 |        13.29 |             13 |         76.56 |
| Cloudy              |     325 |        13.07 |             13 |         73.54 |
| Fog                 |     331 |        12.88 |             13 |         73.11 |

Kruskal–Wallis test across weather conditions: p = 0.9


Effect of each adverse condition (mean delay with vs without, Mann–Whitney p-value):

| condition    |   trips |   mean_delay_with |   mean_delay_without |   diff_min |   p_value |
|:-------------|--------:|------------------:|---------------------:|-----------:|----------:|
| is_rain      |     658 |            13.451 |               13.253 |      0.199 |     0.69  |
| is_snow      |     343 |            13.534 |               13.273 |      0.26  |     0.608 |
| is_fog       |     331 |            12.879 |               13.405 |     -0.526 |     0.365 |
| extreme_temp |     389 |            13.175 |               13.353 |     -0.178 |     0.755 |
| heavy_precip |     208 |            13.168 |               13.335 |     -0.167 |     0.776 |
| high_wind    |     226 |            12.544 |               13.417 |     -0.872 |     0.18  |

Mean delay by temperature band:

| temperature_c   |   mean |   count |
|:----------------|-------:|--------:|
| ≤0°C            |  13.95 |     233 |
| 0–10            |  13.37 |     514 |
| 10–20           |  13.65 |     492 |
| 20–30           |  13.02 |     501 |
| >30°C           |  12.6  |     260 |

![](figures/02_weather_effect.png)

## 3. City events

- P(delay > 5 min) **with** an event nearby: **74.1%**
- P(delay > 5 min) **without** an event: **75.5%**
- Relative risk: **0.98×** (chi-square p = 0.51)

| event_type   |   trips |   mean_delay |   pct_delayed |
|:-------------|--------:|-------------:|--------------:|
| Protest      |      86 |        13.9  |         76.74 |
| Parade       |     105 |        13.62 |         76.19 |
| None         |    1173 |        13.53 |         75.53 |
| Concert      |     203 |        12.83 |         73.4  |
| Sports       |     212 |        12.82 |         72.17 |
| Festival     |     221 |        12.77 |         74.66 |

![](figures/03_event_effect.png)

## 4. Time patterns

**Peak hour (1) vs off-peak (0)** — mean delay:

|   peak_hour |   mean_delay_min |
|------------:|-----------------:|
|           0 |            13.3  |
|           1 |            13.36 |

**Season** — mean delay:

| season   |   mean_delay_min |
|:---------|-----------------:|
| Autumn   |            13.89 |
| Spring   |            13.4  |
| Summer   |            12.72 |
| Winter   |            13.31 |

**Transport type** — mean delay:

| transport_type   |   mean_delay_min |
|:-----------------|-----------------:|
| Tram             |            12.95 |
| Metro            |            13.21 |
| Bus              |            13.54 |
| Train            |            13.55 |

![](figures/04_time_patterns.png)

![](figures/05_correlations.png)

## 5. Models

Chronological split (train on earliest 80% of trips, test on latest 20%); CV = 5-fold on the training set.

| model                      |   CV_MAE |   CV_RMSE |   CV_R2 |   Test_MAE |   Test_RMSE |   Test_R2 |
|:---------------------------|---------:|----------:|--------:|-----------:|------------:|----------:|
| Baseline (mean)            |    7.905 |     9.248 |  -0.003 |      8.155 |       9.459 |    -0.004 |
| Linear Regression          |    8.415 |     9.975 |  -0.168 |      8.19  |       9.578 |    -0.029 |
| Ridge Regression           |    7.935 |     9.296 |  -0.014 |      8.15  |       9.473 |    -0.007 |
| Random Forest              |    7.98  |     9.385 |  -0.033 |      8.102 |       9.456 |    -0.003 |
| Gradient Boosting (HistGB) |    8.268 |     9.787 |  -0.124 |      8.232 |       9.741 |    -0.065 |

**Best model: Ridge Regression** — test MAE 8.15 min, RMSE 9.47, R² -0.007 (baseline MAE 8.15, 0% better).

![](figures/06_model_results.png)

### Top features (permutation importance)

| feature                  |   importance |    std |
|:-------------------------|-------------:|-------:|
| temperature_c            |       0.0159 | 0.009  |
| weekday                  |       0.011  | 0.008  |
| time_cos                 |       0.0068 | 0.0084 |
| holiday                  |       0.006  | 0.0062 |
| high_wind                |       0.0045 | 0.0019 |
| origin_station           |       0.0045 | 0.0019 |
| destination_station      |       0.003  | 0.0018 |
| event_x_peak             |       0.0022 | 0.0068 |
| log_attendance           |       0.0015 | 0.0088 |
| time_sin                 |       0.0014 | 0.0035 |
| has_event                |       0.001  | 0.0087 |
| is_snow                  |       0.0005 | 0.004  |
| bad_weather              |       0.0003 | 0.0002 |
| temp_dev_from_comfort    |       0.0002 | 0.0011 |
| traffic_congestion_index |       0.0001 | 0.0005 |

![](figures/07_feature_importance.png)


_Note: `actual_departure_delay_min` was excluded — it is only known after the trip starts, so using it would leak the answer. Run with `--include-departure-delay` to see its effect._
